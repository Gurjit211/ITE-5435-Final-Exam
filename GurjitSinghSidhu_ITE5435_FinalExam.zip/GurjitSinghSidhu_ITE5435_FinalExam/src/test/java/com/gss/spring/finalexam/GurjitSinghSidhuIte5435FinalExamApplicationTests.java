package com.gss.spring.finalexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GurjitSinghSidhuIte5435FinalExamApplicationTests {

    @Test
    void contextLoads() {
    }

}
