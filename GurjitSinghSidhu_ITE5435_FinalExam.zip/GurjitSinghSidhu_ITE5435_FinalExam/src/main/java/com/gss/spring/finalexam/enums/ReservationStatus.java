package com.gss.spring.finalexam.enums;

public enum ReservationStatus { CREATED, CONFIRMED, CANCELLED }
