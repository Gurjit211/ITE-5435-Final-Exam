package com.gss.spring.finalexam.controller;

import com.gss.spring.finalexam.dto.ReservationCreateRequest;
import com.gss.spring.finalexam.model.Reservation;
import com.gss.spring.finalexam.enums.ReservationStatus;
import com.gss.spring.finalexam.service.ReservationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reservations")
public class ReservationApiController {

    private final ReservationService service;

    public ReservationApiController(ReservationService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Reservation> create(@RequestBody ReservationCreateRequest req) {
        Reservation created = service.createReservation(req.customer(), req.payment(), req.reservation());
        return ResponseEntity.ok(created);
    }

    @GetMapping
    public ResponseEntity<List<Reservation>> list() {
        return ResponseEntity.ok(service.listAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Reservation> get(@PathVariable String id) {
        Reservation r = service.getById(id);
        return r != null ? ResponseEntity.ok(r) : ResponseEntity.notFound().build();
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<Reservation> updateStatus(@PathVariable String id, @RequestParam ReservationStatus status) {
        Reservation r = service.updateStatus(id, status);
        return r != null ? ResponseEntity.ok(r) : ResponseEntity.notFound().build();
    }
}
