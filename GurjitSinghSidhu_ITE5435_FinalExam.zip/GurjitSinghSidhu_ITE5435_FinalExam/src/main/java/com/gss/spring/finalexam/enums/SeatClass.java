package com.gss.spring.finalexam.enums;

public enum SeatClass { ECONOMY, PREMIUM_ECONOMY, BUSINESS, FIRST }
