package com.gss.spring.finalexam.dto;

import com.gss.spring.finalexam.model.Customer;
import com.gss.spring.finalexam.model.Payment;
import com.gss.spring.finalexam.model.Reservation;

public record ReservationCreateRequest(
        Customer customer,
        Payment payment,
        Reservation reservation
) {}
