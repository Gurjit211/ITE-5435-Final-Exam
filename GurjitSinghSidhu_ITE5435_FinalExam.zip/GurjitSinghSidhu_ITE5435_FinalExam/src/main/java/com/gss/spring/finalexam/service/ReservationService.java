package com.gss.spring.finalexam.service;

import com.gss.spring.finalexam.enums.PaymentStatus;
import com.gss.spring.finalexam.enums.ReservationStatus;
import com.gss.spring.finalexam.enums.SeatClass;
import com.gss.spring.finalexam.model.Customer;
import com.gss.spring.finalexam.model.Payment;
import com.gss.spring.finalexam.model.Reservation;
import com.gss.spring.finalexam.repository.CustomerRepository;
import com.gss.spring.finalexam.repository.PaymentRepository;
import com.gss.spring.finalexam.repository.ReservationRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReservationService {

    private final CustomerRepository customerRepository;
    private final PaymentRepository paymentRepository;
    private final ReservationRepository reservationRepository;

    public ReservationService(CustomerRepository customerRepository,
                              PaymentRepository paymentRepository,
                              ReservationRepository reservationRepository) {
        this.customerRepository = customerRepository;
        this.paymentRepository = paymentRepository;
        this.reservationRepository = reservationRepository;
    }

    public Reservation createReservation(Customer c, Payment p, Reservation r) {
        Customer savedCustomer = customerRepository.save(c);

        p.setStatus(PaymentStatus.PENDING);
        Payment savedPayment = paymentRepository.save(p);

        r.setCustomerId(savedCustomer.getId());
        r.setStatus(ReservationStatus.CREATED);
        return reservationRepository.save(r);
    }

    public List<Reservation> listAll() {
        return reservationRepository.findAll();
    }

    public Reservation getById(String id) {
        return reservationRepository.findById(id).orElse(null);
    }

    public Reservation updateStatus(String id, ReservationStatus status) {
        Reservation res = getById(id);
        if (res == null) return null;
        res.setStatus(status);
        return reservationRepository.save(res);
    }

    public Reservation update(String id, String flightNumber, SeatClass seatClass, ReservationStatus status) {
        Reservation res = getById(id);
        if (res == null) return null;
        res.setFlightNumber(flightNumber);
        res.setSeatClass(seatClass);
        res.setStatus(status);
        return reservationRepository.save(res);
    }

    public void deleteById(String id) {
        reservationRepository.deleteById(id);
    }
}
