package com.gss.spring.finalexam.enums;

public enum PaymentMethod { CREDIT_CARD, DEBIT_CARD, PAYPAL }
