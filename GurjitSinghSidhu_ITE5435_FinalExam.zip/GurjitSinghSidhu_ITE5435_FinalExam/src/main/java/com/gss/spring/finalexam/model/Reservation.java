package com.gss.spring.finalexam.model;

import com.gss.spring.finalexam.enums.ReservationStatus;
import com.gss.spring.finalexam.enums.SeatClass;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "reservations")
public class Reservation {
    @Id
    private String id;
    private String customerId;
    private String flightNumber;
    private SeatClass seatClass;
    private ReservationStatus status;
}
