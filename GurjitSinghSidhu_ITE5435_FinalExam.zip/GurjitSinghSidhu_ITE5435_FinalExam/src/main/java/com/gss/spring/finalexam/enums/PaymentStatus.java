package com.gss.spring.finalexam.enums;

public enum PaymentStatus { PENDING, PAID, FAILED }
