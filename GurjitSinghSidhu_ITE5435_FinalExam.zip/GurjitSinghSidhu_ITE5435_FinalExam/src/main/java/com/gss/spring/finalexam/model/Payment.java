package com.gss.spring.finalexam.model;

import com.gss.spring.finalexam.enums.PaymentMethod;
import com.gss.spring.finalexam.enums.PaymentStatus;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "payments")
public class Payment {
    @Id
    private String id;
    private double amount;
    private PaymentMethod method;
    private PaymentStatus status;
}
