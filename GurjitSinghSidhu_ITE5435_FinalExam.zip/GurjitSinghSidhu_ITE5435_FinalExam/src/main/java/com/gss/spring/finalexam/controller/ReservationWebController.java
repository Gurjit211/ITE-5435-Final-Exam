package com.gss.spring.finalexam.controller;

import com.gss.spring.finalexam.enums.PaymentMethod;
import com.gss.spring.finalexam.enums.PaymentStatus;
import com.gss.spring.finalexam.enums.ReservationStatus;
import com.gss.spring.finalexam.enums.SeatClass;
import com.gss.spring.finalexam.model.Customer;
import com.gss.spring.finalexam.model.Payment;
import com.gss.spring.finalexam.model.Reservation;
import com.gss.spring.finalexam.service.ReservationService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class ReservationWebController {

    private final ReservationService service;

    public ReservationWebController(ReservationService service) {
        this.service = service;
    }

    @ModelAttribute("seatClasses")
    public SeatClass[] seatClasses() {
        return SeatClass.values();
    }

    @ModelAttribute("paymentMethods")
    public PaymentMethod[] paymentMethods() {
        return PaymentMethod.values();
    }

    @ModelAttribute("statuses")
    public ReservationStatus[] statuses() {
        return ReservationStatus.values();
    }

    @GetMapping("/")
    public String showForm() {
        return "reservation_form";
    }

    @PostMapping("/reserve")
    public String submit(@RequestParam String firstName,
                         @RequestParam String lastName,
                         @RequestParam String email,
                         @RequestParam String phone,
                         @RequestParam double amount,
                         @RequestParam PaymentMethod method,
                         @RequestParam String flightNumber,
                         @RequestParam SeatClass seatClass,
                         Model model,
                         RedirectAttributes ra) {
        Customer c = new Customer();
        c.setFirstName(firstName);
        c.setLastName(lastName);
        c.setEmail(email);
        c.setPhone(phone);

        Payment p = new Payment();
        p.setAmount(amount);
        p.setMethod(method);
        p.setStatus(PaymentStatus.PENDING);

        Reservation r = new Reservation();
        r.setFlightNumber(flightNumber);
        r.setSeatClass(seatClass);

        Reservation created = service.createReservation(c, p, r);
        model.addAttribute("reservation", created);
        ra.addFlashAttribute("msg", "Reservation created");
        return "reservation_success";
    }

    @GetMapping("/reservations")
    public String list(Model model) {
        model.addAttribute("items", service.listAll());
        return "reservations_list";
    }

    @GetMapping("/reservations/{id}/edit")
    public String edit(@PathVariable String id, Model model, RedirectAttributes ra) {
        Reservation res = service.getById(id);
        if (res == null) {
            ra.addFlashAttribute("msg", "Reservation not found");
            return "redirect:/reservations";
        }
        model.addAttribute("reservation", res);
        return "edit_reservation";
    }

    @PostMapping("/reservations/{id}")
    public String update(@PathVariable String id,
                         @RequestParam String flightNumber,
                         @RequestParam SeatClass seatClass,
                         @RequestParam ReservationStatus status,
                         RedirectAttributes ra) {
        service.update(id, flightNumber, seatClass, status);
        ra.addFlashAttribute("msg", "Reservation updated");
        return "redirect:/reservations";
    }

    @PostMapping("/reservations/{id}/delete")
    public String delete(@PathVariable String id, RedirectAttributes ra) {
        service.deleteById(id);
        ra.addFlashAttribute("msg", "Reservation deleted");
        return "redirect:/reservations";
    }

    @PostMapping("/reservations/updateStatus")
    public String updateStatusFromForm(@RequestParam String id,
                                       @RequestParam ReservationStatus status,
                                       RedirectAttributes ra) {
        service.updateStatus(id, status);
        ra.addFlashAttribute("msg", "Status updated");
        return "redirect:/reservations";
    }
}
